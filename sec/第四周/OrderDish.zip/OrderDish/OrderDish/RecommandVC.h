//
//  RecommandVC.h
//  OrderDish
//
//  Created by sunhuayu on 15/8/30.
//  Copyright (c) 2015年 sunhuayu. All rights reserved.
//

#import "LeftVC.h"

@interface RecommandVC : LeftVC{
    
}

@end
