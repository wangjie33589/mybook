//
//  RoomVC.h
//  OrderDish
//
//  Created by sunhuayu on 15/8/30.
//  Copyright (c) 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SendOrderVC.h"

@interface RoomVC : UIViewController{
    NSArray         *_array;
}

@property (nonatomic,assign)SendOrderVC *previousVC;


@end







