//
//  People.h
//  CoreDataDemo4
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <CoreData/CoreData.h>
#import "Car.h"

@interface People : NSManagedObject

@property (nonatomic,copy)NSString *name;

@property (nonatomic,retain)NSSet *cars;


@end




@interface People (CoreDataGeneratedAccessors)
//如果某个属性声明为多个类型的，那么需要为这个属性声明add方法，但是不用实现(父类中已经实现了)。
- (void)addCarsObject:(Car *)object;

- (void)removeCarsObject:(Car *)object;
@end



