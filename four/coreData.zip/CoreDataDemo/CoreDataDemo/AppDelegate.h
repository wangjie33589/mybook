//
//  AppDelegate.h
//  CoreDataDemo
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


//对象管理上下文，用于操作对象的增删改查。
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;


//存储对象的模型。
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;


//存储文件的位置。
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;


- (void)saveContext;


- (NSURL *)applicationDocumentsDirectory;


@end

