//
//  Phone.m
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "Phone.h"
#import "People.h"

@implementation Phone

// Insert code here to add functionality to your managed object subclass

@end
