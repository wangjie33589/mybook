//
//  People.m
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People

// Insert code here to add functionality to your managed object subclass

@end
