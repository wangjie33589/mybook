//
//  ViewController.m
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import <CoreData/CoreData.h>
#import "AppDelegate.h"
#import "People.h"
#import "PeopleVC.h"
#import <objc/message.h>

#define APP_DELEGATE (AppDelegate *)[[UIApplication sharedApplication] delegate]

#define COREDATA_CONTEXT [(AppDelegate *)[[UIApplication sharedApplication] delegate] managedObjectContext]

@interface ViewController ()

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self refreshData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _peopleArray = [[NSMutableArray alloc] init];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _peopleArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    People *p = [_peopleArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = p.name;
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    People *p = [_peopleArray objectAtIndex:indexPath.row];
    
    [self performSegueWithIdentifier:@"toPeopleVC" sender:p];
    
    
    
}

- (void)refreshData{
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"People" inManagedObjectContext:COREDATA_CONTEXT];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    
    request.entity = entity;
    
    NSArray *arr = [COREDATA_CONTEXT executeFetchRequest:request error:nil];
    
    [_peopleArray setArray:arr];
    
    [_tableView reloadData];
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    PeopleVC *vc = [segue destinationViewController];
    
    vc.people = sender;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
