//
//  ViewController.h
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    
    __weak IBOutlet UITableView *_tableView;
    
    NSMutableArray      *_peopleArray;
}


@end

