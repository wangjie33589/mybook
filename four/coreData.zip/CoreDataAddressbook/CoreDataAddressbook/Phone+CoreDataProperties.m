//
//  Phone+CoreDataProperties.m
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Phone+CoreDataProperties.h"

@implementation Phone (CoreDataProperties)

@dynamic number;
@dynamic people;

@end
