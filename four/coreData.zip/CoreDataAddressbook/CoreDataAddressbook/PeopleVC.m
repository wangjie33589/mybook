//
//  PeopleVC.m
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "PeopleVC.h"
#import "Phone.h"
#import "AppDelegate.h"

#define APP_DELEGATE (AppDelegate *)[[UIApplication sharedApplication] delegate]

#define COREDATA_CONTEXT [(AppDelegate *)[[UIApplication sharedApplication] delegate] managedObjectContext]

@interface PeopleVC ()

@end

@implementation PeopleVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //_numberArray = [[NSMutableArray alloc] init];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    if (self.people) {
        _nameField.text = self.people.name;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.people.phone.count;
    
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    NSArray *arr = self.people.phone.allObjects;
    
    Phone *phone = [arr objectAtIndex:indexPath.row];
    
    cell.textLabel.text = phone.number;
    
    return cell;
}
    



- (IBAction)buttonClick:(UIButton *)sender {
    
    if (!self.people) {
        self.people = [NSEntityDescription insertNewObjectForEntityForName:@"People" inManagedObjectContext:COREDATA_CONTEXT];
        
        self.people.name = _nameField.text;
        
    }
    Phone *phone = [NSEntityDescription insertNewObjectForEntityForName:@"Phone" inManagedObjectContext:COREDATA_CONTEXT];
    
    phone.number = _numberField.text;
    
    [self.people addPhoneObject:phone];
    
    [APP_DELEGATE saveContext];
    
    
    _numberField.text = @"";
    
    [self.view endEditing:YES];
    
    [_tableView reloadData];
}





@end










