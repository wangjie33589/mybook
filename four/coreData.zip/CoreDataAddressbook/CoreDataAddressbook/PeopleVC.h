//
//  PeopleVC.h
//  CoreDataAddressbook
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "People.h"

@interface PeopleVC : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    
    __weak IBOutlet UITextField *_nameField;
    __weak IBOutlet UITextField *_numberField;
    __weak IBOutlet UITableView *_tableView;
    
    NSMutableArray      *_numberArray;
}


@property (nonatomic,retain)People *people;


@end





