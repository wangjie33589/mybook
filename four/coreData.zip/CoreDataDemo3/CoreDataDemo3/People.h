//
//  People.h
//  CoreDataDemo3
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <CoreData/CoreData.h>
#import "Car.h"

@interface People : NSManagedObject

@property (nonatomic,copy)NSString *name;
@property (nonatomic,strong)Car *car;


@end






