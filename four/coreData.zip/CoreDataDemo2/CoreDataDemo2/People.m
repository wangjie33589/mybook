//
//  People.m
//  CoreDataDemo2
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People



//继承NSManagedObject必须用@dynamic,但是不用实现具体方法，因为父类中已经实现过。
@dynamic name;
@dynamic age;



@end







