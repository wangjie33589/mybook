//
//  People.h
//  CoreDataDemo2
//
//  Created by sunhuayu on 15/10/23.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <CoreData/CoreData.h>

//对象必须继承于NSManagedObject才能被coreData存储。
@interface People : NSManagedObject{
    NSString    *_name;
    short       _age;
             
}

@property (nonatomic,copy)NSString *name;
@property (nonatomic,assign)short age;

@end













