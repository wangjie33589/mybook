//
//  MyClass.m
//  MyClass
//
//  Created by sunhuayu on 15/10/12.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "MyClass.h"

@implementation MyClass


- (void)beginFlash{
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(timerMethod) userInfo:nil repeats:YES];
}

- (void)endFlash{
    [_timer invalidate];
    _timer = nil;
}

- (void)timerMethod{
    
    UIColor *color = [UIColor colorWithRed:arc4random()%101/100.0 green:arc4random()%101/100.0 blue:arc4random()%101/100.0 alpha:1];
    
    self.backgroundColor = color;
}


@end









