//
//  MyClass.h
//  MyClass
//
//  Created by sunhuayu on 15/10/12.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MyClass : UIView{
    NSTimer     *_timer;
}


- (void)beginFlash;

- (void)endFlash;


@end







