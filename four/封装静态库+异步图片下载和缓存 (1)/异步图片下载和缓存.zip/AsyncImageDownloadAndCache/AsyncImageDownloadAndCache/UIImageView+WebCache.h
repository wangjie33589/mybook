//
//  UIImageView+WebCache.h
//  AsyncImageDownloadAndCache
//
//  Created by sunhuayu on 15/10/12.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (WebCache)

- (void)setImageWithURL:(NSURL *)url;

@end











