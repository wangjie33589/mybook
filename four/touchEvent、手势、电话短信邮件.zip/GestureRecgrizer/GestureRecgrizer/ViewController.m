//
//  ViewController.m
//  GestureRecgrizer
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end


@implementation MyView


- (BOOL)canBecomeFirstResponder{
    return YES;
}


@end






@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _myView = [[MyView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
    _myView.center = self.view.center;
    _myView.backgroundColor = [UIColor redColor];
    [self.view addSubview:_myView];
    
    //手势识别器，能够辨识出各种touch事件，UIGestureRecognizer无法直接使用，需要使用它的几个子类。
    //UIGestureRecognizer
    
    /*---------点击手势---------*/
    //手势创建时需要绑定方法，当手势触发时，就会调用这个方法。
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureRecognized:)];
    
    //触发手势所需要的手指数量。
    tapGesture.numberOfTouchesRequired = 1;
    
    //触发手势所需要的点击次数
    tapGesture.numberOfTapsRequired = 1;
    
    //手势需要添加到view上才能使用。
    [_myView addGestureRecognizer:tapGesture];
    
    UITapGestureRecognizer *doubleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapGestureRecognized:)];
    doubleTapGesture.numberOfTapsRequired = 2;
    [_myView addGestureRecognizer:doubleTapGesture];
    
    //当双击手势触发失败才能触发单击手势。
    [tapGesture requireGestureRecognizerToFail:doubleTapGesture];
    
    
    /*--------滑动手势--------*/
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureRecognized:)];
    [_myView addGestureRecognizer:panGesture];
    
    
    /*--------捏合放大手势------*/
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchGestureRecognized:)];
    
    [_myView addGestureRecognizer:pinchGesture];
    
    /*--------旋转手势------*/
    
    UIRotationGestureRecognizer *rotationGesture = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationGestureRecognized:)];
    
    //设置手势的代理
    rotationGesture.delegate = self;
    
    [_myView addGestureRecognizer:rotationGesture];
    
    
    /*---------轻滑手势--------*/
    
    UISwipeGestureRecognizer *swipeGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeGestureRecognized:)];
    
    //设置触发手势的滑动方向
    swipeGesture.direction = UISwipeGestureRecognizerDirectionUp|UISwipeGestureRecognizerDirectionDown;
    
    [self.view addGestureRecognizer:swipeGesture];
    
    
    /*------长按手势--------*/
    
    UILongPressGestureRecognizer *longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressGestureRecognized:)];
    //触发手势的最小按压时间
    longPressGesture.minimumPressDuration = 0.7;
    
    //最大允许的按压移动距离
    longPressGesture.allowableMovement = 10;
    
    [_myView addGestureRecognizer:longPressGesture];
    
    /*---------------------*/
    
//    UIScreenEdgePanGestureRecognizer *edgePan = [[UIScreenEdgePanGestureRecognizer alloc] initWithTarget:self action:@selector(edgePanGestureRecognized:)];
//    edgePan.edges = UIRectEdgeAll;
//    [self.view addGestureRecognizer:edgePan];
    
}

//- (void)edgePanGestureRecognized:(UIScreenEdgePanGestureRecognizer  *)gesture{
//    NSLog(@"边界滑动");
//}

//单击手势
- (void)tapGestureRecognized:(UITapGestureRecognizer *)gesture{
    //gesture.view  gesture所在的view
    gesture.view.transform = CGAffineTransformRotate(gesture.view.transform, 30*M_PI/180);
}

//双击手势
- (void)doubleTapGestureRecognized:(UITapGestureRecognizer *)gesture{
    NSLog(@"双击了");
}

//滑动手势
- (void)panGestureRecognized:(UIPanGestureRecognizer *)gesture{
    //locationInView当前手势所在的坐标
    //CGPoint point1 = [gesture locationInView:gesture.view.superview];

    //translationInView移动偏移量
    CGPoint point2 = [gesture translationInView:gesture.view.superview];
    
    gesture.view.center = CGPointMake(gesture.view.center.x+point2.x, gesture.view.center.y+point2.y);
    
    //把手势偏移量归零。
    [gesture setTranslation:CGPointZero inView:gesture.view];
    
}

//捏合手势
- (void)pinchGestureRecognized:(UIPinchGestureRecognizer *)gesture{
    
    //gesture.scale 放大或缩小的比例，是相对于手势触发开始时的状态。
    gesture.view.transform = CGAffineTransformScale(gesture.view.transform, gesture.scale, gesture.scale);
    
    //如果希望得到每次放大或缩小的比例，那么每次手势触发后，需要将比例还原。
    gesture.scale = 1;
    
    //gesture.velocity缩放的速度
    //NSLog(@"%f",gesture.velocity);
    
}

//旋转手势
- (void)rotationGestureRecognized:(UIRotationGestureRecognizer *)gesture{
    
    gesture.view.transform = CGAffineTransformRotate(gesture.view.transform, gesture.rotation);
    
    gesture.rotation = 0;
    
}

//轻滑手势
- (void)swipeGestureRecognized:(UISwipeGestureRecognizer *)gesture{
    NSLog(@"滑动触发了");
}

//长按手势
- (void)longPressGestureRecognized:(UILongPressGestureRecognizer *)gesture{
    //gesture.state表示触发手势的当前状态。
    //Began表示已经被识别。
    //change表示手势的属性正在变化(用户正在滑动)
    //end表示手势结束
    if (gesture.state == UIGestureRecognizerStateBegan) {
        //菜单控制器,是单例类。
        UIMenuController *menuController = [UIMenuController sharedMenuController];
        UIMenuItem *item1 = [[UIMenuItem alloc] initWithTitle:@"红" action:@selector(redItemClick)];
        UIMenuItem *item2 = [[UIMenuItem alloc] initWithTitle:@"绿" action:@selector(greenItemClick)];
        UIMenuItem *item3 = [[UIMenuItem alloc] initWithTitle:@"蓝" action:@selector(blueItemClick)];
        
        menuController.menuItems = @[item1,item2,item3];
        
        [gesture.view becomeFirstResponder];
        
        //setTargetRect inView方法设置的现实目标view必须成为第一响应，menuController才可能现实出来
        [menuController setTargetRect:gesture.view.bounds inView:gesture.view];
        
        [menuController setMenuVisible:YES animated:YES];
        
        
    }
    
    
}


#pragma mark- gestureDelegate

//设置一个手势是否可以于另外一个手势共同触发
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}


- (void)redItemClick{
    _myView.backgroundColor = [UIColor redColor];
    [_myView resignFirstResponder];
}
- (void)greenItemClick{
    _myView.backgroundColor = [UIColor greenColor];
    [_myView resignFirstResponder];
}
- (void)blueItemClick{
    _myView.backgroundColor = [UIColor blueColor];
    [_myView resignFirstResponder];
}



- (void)motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event{
    if (motion == UIEventSubtypeMotionShake) {
        NSLog(@"摇一摇开始");
    }
    
}




@end




