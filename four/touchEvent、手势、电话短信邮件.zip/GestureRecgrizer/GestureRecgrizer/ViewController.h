//
//  ViewController.h
//  GestureRecgrizer
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

//同一个文件中可以声明多个类。（一般不这样写，仅仅在MyView只在ViewController中使用时，可以这样写）
@interface MyView : UIView

@end

@interface ViewController : UIViewController<UIGestureRecognizerDelegate>{
    MyView  *_myView;
}


@end









