//
//  PhoneCallsVC.h
//  PhoneEmailMessage
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhoneCallsVC : UIViewController{
    
    __weak IBOutlet UIWebView *_webView;
}

@end
