//
//  PhoneCallsVC.m
//  PhoneEmailMessage
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "PhoneCallsVC.h"

@interface PhoneCallsVC ()

@end

@implementation PhoneCallsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSURL *url = [NSURL URLWithString:@"tel://13939095594"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [_webView loadRequest:request];
    
}

- (IBAction)gobackClick:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
