//
//  ViewController.m
//  PhoneEmailMessage
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "PhoneCallsVC.h"



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)phoneCallButtonClick:(UIButton *)sender {
//    NSURL *url = [NSURL URLWithString:@""tel://13939095594];
//    [[UIApplication sharedApplication] openURL:url];
    
    PhoneCallsVC *vc = [[PhoneCallsVC alloc] init];
    
    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)sendMessageClick:(UIButton *)sender {
//    NSURL *url = [NSURL URLWithString:@"sms://13939095594"];
//    [[UIApplication sharedApplication] openURL:url];
    
    MFMessageComposeViewController *vc = [[MFMessageComposeViewController alloc] init];
    
    //短信发送目标号码
    vc.recipients = @[@"10086",@"10010"];
    
    //短信的内容
    vc.body = @"恭喜您获得一等奖";
    
    //设置短信发送代理
    vc.messageComposeDelegate = self;
    
    [self presentViewController:vc animated:YES completion:nil];
    
}

- (IBAction)sendEmailClick:(UIButton *)sender {
    
    MFMailComposeViewController *vc = [[MFMailComposeViewController alloc] init];
    
    //设置邮件发送地址。
    [vc setToRecipients:@[@"452516188@qq.com",@"cocoasunhuayu@163.com"]];
    
    //设置邮件内容
    [vc setMessageBody:@"你好，请转账付费" isHTML:NO];
    
    NSData *data = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"coreAnimation" ofType:@"zip"]];
    
    //添加文件
    [vc addAttachmentData:data mimeType:@"application/zip" fileName:@"coreAnimation.zip"];
    
    //设置邮件发送代理
    vc.mailComposeDelegate = self;
    
    [self presentViewController:vc animated:YES completion:nil];
    
}

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(nullable NSError *)error{
    
    switch (result) {
        case MFMailComposeResultCancelled:
            //取消且不保存
            break;
        case MFMailComposeResultSaved:
            //取消并保存
            break;
        case MFMailComposeResultSent:
            //发送成功
            break;
        case MFMailComposeResultFailed:
            //发送失败
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result{
    if (result == MessageComposeResultCancelled) {
        //用户取消发送
        
    }else if (result == MessageComposeResultFailed){
        //发送失败
    }else{
        //发送成功
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end








