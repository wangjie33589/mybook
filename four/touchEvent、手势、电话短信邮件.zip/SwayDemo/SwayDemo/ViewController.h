//
//  ViewController.h
//  SwayDemo
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    CALayer     *_layer;
}


@end

