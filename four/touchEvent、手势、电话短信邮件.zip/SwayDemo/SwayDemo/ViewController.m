//
//  ViewController.m
//  SwayDemo
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _layer = [CALayer layer];
    
    _layer.bounds = CGRectMake(0, 0, 200, 130);
    _layer.anchorPoint = CGPointMake(0.5, 0);
    _layer.position = self.view.center;
    _layer.contents = (__bridge id)([[UIImage imageNamed:@"123.jpg"] CGImage]);
    [self.view.layer addSublayer:_layer];
    
    CATransform3D transform = _layer.transform;
    transform.m34 = 0.003;
    _layer.transform = transform;
    
    transform = CATransform3DRotate(_layer.transform, 15*M_PI/180, 1, 0, 0);
    _layer.transform = transform;
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    animation.toValue = @(-15*M_PI/180);
    animation.duration = 0.7;
    animation.autoreverses = YES;
    animation.repeatCount = HUGE_VAL;
    
    [_layer addAnimation:animation forKey:@"sway"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
