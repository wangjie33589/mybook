//
//  MoveView.m
//  TouchEvent
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "MoveView.h"

@implementation MoveView


//当手指接触屏幕的瞬间调用
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    //[CATransaction setDisableActions:YES];
    CGPoint pointInSuperView = [touch locationInView:self.superview];
    
    self.center = pointInSuperView;
    self.layer.anchorPoint = CGPointMake(point.x/100, point.y/100);
    
    
}

//当手指在屏幕上滑动时调用(滑动时连续不停的多次调用)
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    //UITouch触碰类，NSSet 集合类，只能存放对象，和数组类似，但是集合中的对象是无序的。
    UITouch *touch = [touches anyObject];
    
    //locationInView获得本次touch在某个view上的坐标。
    CGPoint point = [touch locationInView:self.superview];
    
    self.center = point;
}

//手指离开屏幕的瞬间调用
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"end");
}

//当touch事件被其他事件终止时调用。一般和touchEnd做同样的处理
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"cancle");
}


@end











