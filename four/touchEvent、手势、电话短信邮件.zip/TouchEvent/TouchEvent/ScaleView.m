//
//  ScaleView.m
//  TouchEvent
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ScaleView.h"

@implementation ScaleView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        //允许多点触控
        self.multipleTouchEnabled = YES;
    }
    return self;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //把集合中的对象放入数组
    NSArray *array = [touches allObjects];
    if (array.count == 2) {
        UITouch *touch1 = [array firstObject];
        UITouch *touch2 = [array lastObject];
        CGPoint point1 = [touch1 locationInView:self.superview];
        CGPoint point2 = [touch2 locationInView:self.superview];
        
        _distance = sqrt(pow(point2.x-point1.x, 2)+pow(point2.y-point1.y, 2));
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSArray *array = [touches allObjects];
    if (array.count == 2) {
        UITouch *touch1 = [array firstObject];
        UITouch *touch2 = [array lastObject];
        CGPoint point1 = [touch1 locationInView:self.superview];
        CGPoint point2 = [touch2 locationInView:self.superview];
        
        double distance = sqrt(pow(point2.x-point1.x, 2)+pow(point2.y-point1.y, 2));
        
        double scale = distance/_distance;
        self.transform = CGAffineTransformScale(self.transform, scale, scale);
        _distance = distance;
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}

@end









