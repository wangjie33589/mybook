//
//  ViewController.m
//  TouchEvent
//
//  Created by sunhuayu on 15/10/14.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "MoveView.h"
#import "ScaleView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    MoveView *view = [[MoveView alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
    view.backgroundColor = [UIColor redColor];
    [self.view addSubview:view];
    
    ScaleView *view2 = [[ScaleView alloc] initWithFrame:CGRectMake(50, 200, 100, 100)];
    view2.center = self.view.center;
    view2.backgroundColor = [UIColor greenColor];
    [self.view addSubview:view2];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
