//
//  ViewController.m
//  PredicateDemo
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *str1 = @"123";
    
    //前缀
    //NSLog(@"%d",[str1 hasPrefix:@"a"]);
    
    //后缀
    //[str1 hasSuffix:]
    
    
    //NSPredicate 谓词。用于匹配判断。
    
    //beginswith判断是否是。。开头。
    //endswith判断是否以。。结尾。
    //contains判断是否包含。。。
    //[c]表示不区分大小写。
    //[d]表示不区分重音。
    //[cd]既不区分大小写也不区分重音。
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains[c] 'abc'"];
    
    NSString *str2 = @"ABCDEFG";
    
    //evaluateWithObject判断某个对象是否满足谓词条件。
    NSLog(@"%d",[predicate evaluateWithObject:str2]);
    
    
    NSArray *textArray = @[@"123abc",@"qwe",@"aabccd",@"abc123",@"aabbcc",@"98765",@"AbCdEf"];
    
    //filteredArrayUsingPredicate按照一个谓词条件过滤数组。
    NSArray *newArray = [textArray filteredArrayUsingPredicate:predicate];
    
    NSLog(@"%@",newArray);
    
    
}

- (IBAction)buttonClick:(UIButton *)sender {
    
    //正则表达式，用于字符串匹配判断。
    NSString *regex = @"^[\u4E00-\u9FA5]+$";
    
    //用正则表达式生成谓词
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self matches %@",regex];
    
    if ([predicate evaluateWithObject:_textField.text]) {
        NSLog(@"是中文");
    }else{
        NSLog(@"不是");
    }
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
