//
//  MyViewController.m
//  ViewControllerLife
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "MyViewController.h"

@interface MyViewController ()

@end

@implementation MyViewController




- (instancetype)init{
    self = [super init];
    if (self) {
        
        //当vc创建时，vc.view并没有创建，当调用vc.view的get方法时，方法内部会先进行判断，如果view存在则直接返回。如果view不存在则调用loadView方法创建view，然后调用viewDidLoad，再返回view。
        //vc.view在第一次调用view的get方法时创建。
        
        //self.view.backgroundColor = [UIColor redColor];
        NSLog(@"4---%s",__FUNCTION__);
    }
    return self;
}

//加载视图，在view的get方法中会进行判断，如果没有view，就会调用loadView方法加载view。（只调一次）
- (void)loadView{
    [super loadView];
    
    
}

//视图加载完成(loadView之后)时调用。（只调一次）
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"5---%s",__FUNCTION__);
    self.view.backgroundColor = [UIColor blueColor];
}


- (void)viewWillAppear:(BOOL)animated{
    
}

- (void)viewDidAppear:(BOOL)animated{
    
}

- (void)viewWillDisappear:(BOOL)animated{
    
}

- (void)viewDidDisappear:(BOOL)animated{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
