//
//  People.h
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dog.h"

@interface People : NSObject{
    NSString        *_name;
    
    int             _age;
    
    Dog             *_dog;
}

- (instancetype)initWithName:(NSString *)name;



@end









