//
//  Dog.m
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "Dog.h"

@implementation Dog


- (instancetype)initWithDictionary:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        for (NSString *key in [dic allKeys]) {
            
            [self setValue:[dic objectForKey:key] forKey:key];
        }
    }
    return self;
}

@end












