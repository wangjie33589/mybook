//
//  ViewController.h
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "People.h"

@interface ViewController : UIViewController{
    People      *_p;
    
    
    __weak IBOutlet UITextField *_textField;
    
    
    __weak IBOutlet UILabel *_label;
    
    __weak IBOutlet UILabel *_label2;
    
    
    
    
}


@property (nonatomic,copy)NSString *string;


@end









