//
//  ViewController.m
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //KVC - key value coding,键值编码，允许通过键来直接修改或访问对象的某个属性。
    
    //KVC在进行访问某个属性时，会根据键name,首先选择调用name的get方法访问，如果对象没有name的get方法，则会获取对象的_name属性值，如果name的get方法和_name属性都不存在，则会调用对象的valueForUndeffinedKey.
    
    //KVC修改某个键值时，优先使用set方法，其次使用修改 _键 属性的值，如果方法和属性都不存在，则调用对象的setValueForUndeffinedKey。
    
    
    _p = [[People alloc] initWithName:@"大壮"];
    
    
    [_p setValue:@12 forKey:@"123"];
    
    [_p setValue:@"小明" forKey:@"name"];
    
    
    NSLog(@"%d",[[_p valueForKey:@"age"] intValue]);
    
    
    //KeyPath键路径，能够修改或访问多层次的属性。
    [_p setValue:@"red" forKeyPath:@"dog.color"];
    
    
    NSLog(@"%@",[_p valueForKeyPath:@"dog.color"]);
    
    
    /*------------------------*/
    
    //KVO-- key value observe
    
    //textField把self添加为text属性的观察者，每当textField的text属性发生变化时，self就会知道。(会调用self的观察者方法)
    [_label addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew context:nil];
    
    
    _label.text = @"abc";
    
    
    [self addObserver:self forKeyPath:@"string" options:NSKeyValueObservingOptionNew context:nil];
    
    
}

- (IBAction)buttonClick:(UIButton *)sender {
    //_label.text = _textField.text;
    
    //必须通过set方法或者kvc修改属性时，kvo才能监视到属性的变化。
    //_string = @"123";
    self.string = @"123";
}


//观察者方法。当所观察的对象的观察属性发生变化时就会调用这个方法。
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    NSLog(@"%@",change);
    _label2.text = [change objectForKey:@"new"];
}



- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
