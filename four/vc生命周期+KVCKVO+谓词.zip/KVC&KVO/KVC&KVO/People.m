//
//  People.m
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    NSLog(@"你正在给一个不存在的属性赋值");
}

- (id)valueForUndefinedKey:(NSString *)key{
    return @"这是一个不存在的属性";
}

- (instancetype)initWithName:(NSString *)name{
    self = [super init];
    if (self) {
        _name = [name copy];
        
        _dog = [[Dog alloc] init];
        
    }
    return self;
}

@end













