//
//  Dog.h
//  KVC&KVO
//
//  Created by sunhuayu on 15/10/22.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dog : NSObject{
    
    NSString        *_color;
    
}



@end








