//
//  ViewController.h
//  MemoryARC
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "People.h"

@interface ViewController : UIViewController{
    
    //如果一个指针没有声明引用类型，那么默认为strong类型。
    
    //__strong，强引用指针，指向的对象不会被释放。
    //__weak指针指向的对象释放的时候，这个指针会自动指向nil。
    __weak People  *_p;
    
    
    //__unsafe_unretained  相当于assign，当指向的对象释放时，不会自动指向nil。
    
}

//ARC环境中peoperty种的retain就相当于strong.
@property (retain)People *p1;

//weak 只能修饰对象指针。不能修饰基本类型，
@property (weak)People *p2;

//基本类型需要用assign
@property (assign)int a;



@end





