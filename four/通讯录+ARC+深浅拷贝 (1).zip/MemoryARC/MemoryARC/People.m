//
//  People.m
//  MemoryARC
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People


- (void)work{
    NSLog(@"工作");
}

- (void)dealloc{
    NSLog(@"people释放了");
    
    //ARC环境下dealloc中不能写super dealloc
    //[super dealloc];
}

@end










