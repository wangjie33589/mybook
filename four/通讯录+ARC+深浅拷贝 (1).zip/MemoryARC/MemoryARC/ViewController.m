//
//  ViewController.m
//  MemoryARC
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)dealloc{
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //People *p = [[People alloc] init];
    
    //在ARC环境中，release,autorelease,retain不能使用。
    //[p retain];
    //NSLog(@"%d",p.retainCount);
    
    
    //在ARC环境中，只要还有一个strong类型的指针指向这个对象，这个对象就不会释放。(如果一个对象当前没有strong类型的指针指向，那么它就会释放)
    
    People *p = [[People alloc] init];
    
    _p = p;
    
    //NSLog(@"123");
    
    
    
}

- (IBAction)buttonClick:(UIButton *)sender {
    [_p work];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
