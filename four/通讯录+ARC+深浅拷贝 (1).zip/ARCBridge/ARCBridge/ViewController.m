//
//  ViewController.m
//  ARCBridge
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "People.h"
#import <objc/message.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)dealloc{
    CFRelease(_ref);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *str = [NSString stringWithFormat:@"123"];
    
    //__bridge用于OC中类型和C语言中类型的相互转换。
    NSObject *obj = [[NSObject alloc] init];
    void *o = (__bridge void *)obj;
    
    
    //ARC只适用于OC中对象的内存管理。CoreFoundation中的底层结构体还是使用引用计数管理。所以在ARC环境中两者不能直接进行强制转换。需要进行桥接。
    
    //__bridge 在进行转换之后，CF结构体的引用计数不发生变化
    
    
    //__bridge_retained，用于把OC的对象转为CF结构体，转换之后，CF结构体的引用计数+1.
    
    //__bridge_transfer，用于把CF结构体转为OC对象，转换之后，CF结构体的引用计数-1
    
    
    _ref = (__bridge_retained  CFStringRef)str;
    
    
    //如果在ARC工程中想要使用非ARC文件，需要在文件的编译选项中添加 -fno-objc-arc
    
    //在非ARC工程中使用ARC文件，需要添加 -fobjc-arc
    
    
    People *p = [[People alloc] init];
    
    //ARC环境下没有声明的方法不能在类外部调用。
    //[p speak];
    
    
}


- (IBAction)buttonClick:(UIButton *)sender {
    NSLog(@"%@",_ref);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
