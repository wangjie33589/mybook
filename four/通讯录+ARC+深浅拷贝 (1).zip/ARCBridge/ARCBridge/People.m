//
//  People.m
//  ARCBridge
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People

- (void)speak{
    NSLog(@"说话");
    
}

- (NSArray *)makeArray{
    NSArray *array = [[NSArray alloc] initWithObjects:@"123", nil];
    return [array autorelease];
}

@end






