//
//  ViewController.h
//  ARCBridge
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>


 //ARC环境中结构体中不能声明类指针，只能使用基本类型。
//struct MyStruct {
//    int a;
//    NSString *str;
//};


@interface ViewController : UIViewController{
    CFStringRef _ref;
}




@end






