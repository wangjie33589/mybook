//
//  ViewController.m
//  AddressBook
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)buttonClick:(UIButton *)sender {
    ABPeoplePickerNavigationController *vc = [[ABPeoplePickerNavigationController alloc] init];
    //设置联系人代理
    vc.peoplePickerDelegate = self;
    [self presentViewController:vc animated:YES completion:nil];
    [vc release];
}


//- (void)peoplePickerNavigationController:(ABPeoplePickerNavigationController*)peoplePicker didSelectPerson:(ABRecordRef)person{
//    NSLog(@"123");
//}

//选择了联系人的某个属性时调用，
- (void)peoplePickerNavigationController:(ABPeoplePickerNavigationController*)peoplePicker didSelectPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier{
    //CFStringRef是NSString的结构体，也就是NSString的数据部分。在非ARC环境下可以相互强制转换。
    
    //获取联系人的姓名
    CFStringRef name = ABRecordCopyCompositeName(person);
    
    _nameLabel.text = (NSString *)name;
    CFRelease(name);
    
    //获取联系人的某个属性（所有电话）
    ABMultiValueRef ref =  ABRecordCopyValue(person, property);
    
    //获取用户所点击的电话的索引值
    int index = ABMultiValueGetIndexForIdentifier(ref, identifier);
    
    //根据点击的索引值，从所有电话中取出点击的电话。
    CFStringRef phoneNumber =  ABMultiValueCopyValueAtIndex(ref, index);
    
    _phoneNumberLabel.text = [self trimString:(NSString *)phoneNumber];
    
    CFRelease(phoneNumber);
    CFRelease(ref);
    
}

//去掉字符串中非数字的字符
- (NSString *)trimString:(NSString *)string{
    
    //数字字符集
    NSCharacterSet *numberSet = [NSCharacterSet decimalDigitCharacterSet];
    NSMutableString *mStr = [NSMutableString stringWithString:string];
    for (int i = mStr.length-1; i>=0; i--) {
        NSString *cha = [mStr substringWithRange:NSMakeRange(i, 1)];
        NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:cha];
        if (![numberSet isSupersetOfSet:set]) {
            [mStr deleteCharactersInRange:NSMakeRange(i, 1)];
        }
    }
    return mStr;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_nameLabel release];
    [_phoneNumberLabel release];
    [super dealloc];
}
@end
