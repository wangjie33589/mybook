//
//  ViewController.h
//  AddressBook
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

//提供了通讯录功能
#import <AddressBook/AddressBook.h>

//提供了通讯录界面
#import <AddressBookUI/AddressBookUI.h>


@interface ViewController : UIViewController<ABPeoplePickerNavigationControllerDelegate>{
    
    IBOutlet UILabel *_nameLabel;
    IBOutlet UILabel *_phoneNumberLabel;
    
}


@end

