//
//  WeatherVC.m
//  WeatherReport
//
//  Created by 孙 化育 on 15-3-30.
//  Copyright (c) 2015年 孙 化育. All rights reserved.
//

#import "WeatherVC.h"
#import "WeatherCell.h"
#import "UIImageView+WebCache.h"

@interface WeatherVC ()

@end

@implementation WeatherVC

- (void)requestWeather{
        //
        //发送天气预报数据请求
    NSString *urlString = [NSString stringWithFormat:@"http://api.map.baidu.com/telematics/v3/weather?location=%@&output=json&ak=EGmbw3jQF3ZccEqiv5hxKekm&mcode=com.BaiduWeather",self.city];
    
        //如果参数字符串中有中文，需要进行urlEncode
    
    urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:20];
    
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    [connection start];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}

- (void)refreshControlDidRefresh:(UIRefreshControl *)refreshCon{
    [self requestWeather];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.tableView.contentInset = UIEdgeInsetsMake(64, 0, 0, 0);
    
    _refreshCon = [[UIRefreshControl alloc] init];
    self.refreshControl = _refreshCon;
    [_refreshCon addTarget:self action:@selector(refreshControlDidRefresh:) forControlEvents:UIControlEventValueChanged];
    _refreshCon.attributedTitle = [[[NSAttributedString alloc] initWithString:@"下拉刷新" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:[UIColor redColor]}] autorelease];
    
    self.title = _city;
    
    _data = [[NSMutableData alloc] init];
    _weatherDic = [[NSMutableDictionary alloc] init];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"WeatherCell" bundle:nil] forCellReuseIdentifier:@"weather"];
    
    [self requestWeather];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(requestWeather) name:UIApplicationDidBecomeActiveNotification object:nil];
    
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"网络异常" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
    [_refreshCon endRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{
    [_data setData:[NSData data]];
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [_data appendData:data];
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    
    NSString *str = [[NSString alloc] initWithData:_data encoding:NSUTF8StringEncoding];
        //NSLog(@"%@",str);
    [str release];
    
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:_data options:NSJSONReadingMutableContainers error:nil];
    
//    if ([[dic objectForKey:@"error"] integerValue] == -3) {
//        NSLog(@"没有这个城市");
//    }
    
    [_weatherDic setDictionary:dic];
    [self.tableView reloadData];
    [_refreshCon endRefreshing];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 140;
        }else if(indexPath.row == 1||indexPath.row == 2){
                //pm2.5
            return 44;
        }else{
                //建议
            return 70;
        }
    }else{
        return 140;
    }
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        if (_isOpen) {
            return 3+[[[[_weatherDic objectForKey:@"results"] objectAtIndex:0] objectForKey:@"index"] count];
        }else{
            return 3;
        }
        
    }else{
        return 3;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    WeatherCell *cell = [tableView dequeueReusableCellWithIdentifier:@"weather"];
    NSArray *weaArray = [[[_weatherDic objectForKey:@"results"] objectAtIndex:0] objectForKey:@"weather_data"];
    NSDictionary *wea = nil;
    if (indexPath.section == 0) {
        wea = [weaArray objectAtIndex:0];
        if (indexPath.row == 1) {
                //pm2.5
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            if (!cell) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"] autorelease];
                cell.detailTextLabel.numberOfLines = 0;
            }
            cell.textLabel.text = @"pm2.5";
            cell.detailTextLabel.text = [[[_weatherDic objectForKey:@"results"] objectAtIndex:0] objectForKey:@"pm25"];
            return cell;
        }else if (indexPath.row == 2){
                //打开或关闭建议
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            if (!cell) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"] autorelease];
                cell.detailTextLabel.numberOfLines = 0;
            }
            cell.textLabel.text = _isOpen?@"关闭":@"点我";
            cell.detailTextLabel.text = @"";
            return cell;
        }else if (indexPath.row>2){
                //建议
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            if (!cell) {
                cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"] autorelease];
                cell.detailTextLabel.numberOfLines = 0;
            }
            NSArray *array = [[[_weatherDic objectForKey:@"results"] objectAtIndex:0] objectForKey:@"index"];
            NSDictionary *dic = [array objectAtIndex:indexPath.row-3];
            cell.textLabel.text = [dic objectForKey:@"title"];
            cell.detailTextLabel.text = [dic objectForKey:@"des"];
            return cell;
        }
    }else{
        wea = [weaArray objectAtIndex:indexPath.row+1];
    }
    [cell.picImageView sd_setImageWithURL:[NSURL URLWithString:[wea objectForKey:@"dayPictureUrl"]]];
    cell.dateLabel.text = [wea objectForKey:@"date"];
    cell.tempLabel.text = [wea objectForKey:@"temperature"];
    cell.weatherLabel.text = [NSString stringWithFormat:@"%@ %@",[wea objectForKey:@"weather"],[wea objectForKey:@"wind"]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row == 2) {
            _isOpen = !_isOpen;
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
        }
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"今天";
    }else{
        return @"今后3天";
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)dealloc {
    [_refreshCon release];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_weatherDic release];
    [_data release];
    self.city = nil;
    [super dealloc];
}
@end









