//
//  ViewController.h
//  WeatherReport
//
//  Created by 孙 化育 on 15-3-30.
//  Copyright (c) 2015年 孙 化育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    
    IBOutlet UITableView *_tableView;
    
    NSMutableArray          *_cityArray;
    
        //把所有的城市按照拼音首字母分成若干小数组，再把这些小数组以首字母为键存入字典。
    NSMutableDictionary     *_cityDic;
    
    NSMutableArray          *_defaultArray;
}


@end

