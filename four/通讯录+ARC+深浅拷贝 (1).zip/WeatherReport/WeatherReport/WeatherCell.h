//
//  WeatherCell.h
//  WeatherReport
//
//  Created by 孙 化育 on 15-3-30.
//  Copyright (c) 2015年 孙 化育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UIImageView *picImageView;

@property (retain, nonatomic) IBOutlet UILabel *dateLabel;

@property (retain, nonatomic) IBOutlet UILabel *tempLabel;

@property (retain, nonatomic) IBOutlet UILabel *weatherLabel;


@end
