//
//  WeatherVC.h
//  WeatherReport
//
//  Created by 孙 化育 on 15-3-30.
//  Copyright (c) 2015年 孙 化育. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherVC : UITableViewController<NSURLConnectionDataDelegate,NSURLConnectionDelegate,UITableViewDataSource,UITableViewDelegate>{
    NSMutableData           *_data;
        //IBOutlet UITableView *_tableView;
    
    NSMutableDictionary     *_weatherDic;
    
    BOOL                    _isOpen;
    
    UIRefreshControl        *_refreshCon;
}

@property (nonatomic,copy)NSString *city;

@end







