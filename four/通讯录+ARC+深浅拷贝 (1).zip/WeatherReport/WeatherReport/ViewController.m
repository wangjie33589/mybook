//
//  ViewController.m
//  WeatherReport
//
//  Created by 孙 化育 on 15-3-30.
//  Copyright (c) 2015年 孙 化育. All rights reserved.
//

#import "ViewController.h"
#import "ChineseToPinyin.h"
#import "WeatherVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)cellLongPress:(UILongPressGestureRecognizer *)gesture{
    if (gesture.state == UIGestureRecognizerStateBegan) {
        UITableViewCell *cell = (UITableViewCell *)gesture.view;
        if ([_defaultArray containsObject:cell.textLabel.text]) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"所选城市已在常用中" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
            return;
        }
        
        [_defaultArray addObject:cell.textLabel.text];
        [[NSUserDefaults standardUserDefaults] setObject:_defaultArray forKey:@"defaultArray"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已添加至常用" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
        [_tableView reloadData];
    }
}

- (NSString *)filePath{
    return [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cityList.plist"];
}


- (void)saveCityArray{
    [_cityArray writeToFile:[self filePath] atomically:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _defaultArray = [[NSMutableArray alloc] initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"defaultArray"]];
    
    if (!_defaultArray) {
        _defaultArray = [[NSMutableArray alloc] init];
    }
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:[self filePath]]) {
        NSMutableArray *array = [NSMutableArray arrayWithObjects:@"郑州",@"北京",@"开封",@"洛阳",@"新乡",@"焦作",@"许昌",@"周口",@"驻马店",@"平顶山",@"三门峡",@"鹤壁",@"商丘",@"南阳",@"安阳",@"信阳",@"济源",@"濮阳", nil];
        [array writeToFile:[self filePath] atomically:YES];
    }
    
    _cityArray = [[NSMutableArray alloc] initWithContentsOfFile:[self filePath]];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _cityDic = [[NSMutableDictionary alloc] init];
    [self separateCitysIntoDictionary];
    
}

    //把所有的城市按照首字母区分，放入字典。
- (void)separateCitysIntoDictionary{
    [_cityDic removeAllObjects];
    for (int i = 0;i<_cityArray.count;i++) {
        NSString *city = [_cityArray objectAtIndex:i];
            //先获得这个城市的拼音首字母
        NSString *pinyinFirstLetter = [[ChineseToPinyin pinyinFromChiniseString:city] substringToIndex:1];
            //先查看字典中有没有这个字母的数组，如果有，就直接把这个城市添加进数组，如果没有，那么创建并添加。
        if (![_cityDic objectForKey:pinyinFirstLetter]) {
            NSMutableArray *arr = [NSMutableArray array];
            [_cityDic setObject:arr forKey:pinyinFirstLetter];
        }
        [[_cityDic objectForKey:pinyinFirstLetter] addObject:city];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _cityDic.count+1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    
    if (section>0) {
        NSString *key = [arr objectAtIndex:section-1];
        
        NSArray *cArr = [_cityDic objectForKey:key];
        return cArr.count;
    }else{
        return _defaultArray.count;
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"] autorelease];
        UILongPressGestureRecognizer *gesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellLongPress:)];
        [cell addGestureRecognizer:gesture];
        [gesture release];
    }
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    
    if (indexPath.section>0) {
        NSString *key = [arr objectAtIndex:indexPath.section-1];
        NSArray *cArr = [_cityDic objectForKey:key];
        cell.textLabel.text = [cArr objectAtIndex:indexPath.row];
    }else{
        cell.textLabel.text = [_defaultArray objectAtIndex:indexPath.row];
    }
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
        //sortedArrayUsingComparator返回一个排序好的数组
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    if (section>0) {
        return [arr objectAtIndex:section-1];
    }else{
        return @"常用 (长按一个城市添加至常用)";
    }
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
        //arr是排序之后的[_cityDic allKeys]
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    
    
    if (indexPath.section>0) {
        NSString *key = [arr objectAtIndex:indexPath.section-1];
        NSArray *cArr = [_cityDic objectForKey:key];
        NSString *city = [cArr objectAtIndex:indexPath.row];
        [_cityArray removeObject:city];
        [self separateCitysIntoDictionary];
        [_tableView reloadData];
        [self saveCityArray];
    }else{
        [_defaultArray removeObjectAtIndex:indexPath.row];
        [_tableView reloadData];
        [[NSUserDefaults standardUserDefaults] setObject:_defaultArray forKey:@"defaultArray"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    NSString *city = nil;
    if (indexPath.section>0) {
        NSString *key = [arr objectAtIndex:indexPath.section-1];
        NSArray *cArr = [_cityDic objectForKey:key];
        city = [cArr objectAtIndex:indexPath.row];
        
    }else{
        city = [_defaultArray objectAtIndex:indexPath.row];
    }
    WeatherVC *vc = [[WeatherVC alloc] init];
    vc.city = city;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
    
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    NSArray *arr = [[_cityDic allKeys] sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        return [[ChineseToPinyin pinyinFromChiniseString:obj1] compare:[ChineseToPinyin pinyinFromChiniseString:obj2]];
    }];
    NSMutableArray *ar = [NSMutableArray arrayWithArray:arr];
    [ar insertObject:@"常用" atIndex:0];
    return ar;
}


- (IBAction)addItemClick:(UIBarButtonItem *)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"添加城市" message:@"请输入城市名称" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    [alert release];
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        NSString *cityName = [alertView textFieldAtIndex:0].text;
            //containsObject判断数组中是否包含某个对象
        if ([_cityArray containsObject:cityName]) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"添加的城市已存在" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
            return;
        }
        [_cityArray addObject:cityName];
        [self separateCitysIntoDictionary];
        [_tableView reloadData];
        [self saveCityArray];
    }
}




- (void)dealloc {
    [_cityDic release];
    [_cityArray release];
    [_tableView release];
    [super dealloc];
}
@end
