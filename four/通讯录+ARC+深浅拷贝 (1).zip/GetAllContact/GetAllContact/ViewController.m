//
//  ViewController.m
//  GetAllContact
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "People.h"
#import "NSString+Pinyin.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)dealloc{
    [_peopleArray release];
    [_tableView release];
    [_peopleDic release];
    [super dealloc];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _peopleArray = [[NSMutableArray alloc] init];
    
    _peopleDic = [[NSMutableDictionary alloc] init];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    _tableView.sectionIndexColor = [UIColor redColor];
    
    //请求通讯录访问权限，请求完成后会调用block，granted为YES表示请求成功。
    ABAddressBookRequestAccessWithCompletion(NULL, ^(bool granted, CFErrorRef error) {
        
        //先创建一个通讯录
        ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
        //从通讯录中复制所有的联系人
        NSArray *allPeople = (NSArray *) ABAddressBookCopyArrayOfAllPeople(addressBook);
        for (int i = 0; i<allPeople.count; i++) {
            ABRecordRef person = [allPeople objectAtIndex:i];
            People *p = [[People alloc] init];
            p.name = (NSString *)ABRecordCopyCompositeName(person);
            
            ABMultiValueRef ref = ABRecordCopyValue(person, kABPersonPhoneProperty);
            
            p.phoneNumber = ABMultiValueCopyValueAtIndex(ref, 0);
            [_peopleArray addObject:p];
            [p release];
            CFRelease(ref);
        }
        CFRelease(allPeople);
        
        for (People *p in _peopleArray) {
            NSString *firstChar = [[[p.name pinyin] substringToIndex:1] uppercaseString];
            
            NSMutableArray *mArr = [_peopleDic objectForKey:firstChar];
            if (!mArr) {
                mArr = [NSMutableArray array];
                [_peopleDic setObject:mArr forKey:firstChar];
            }
            
            [mArr addObject:p];
        }
        
        //对每个小数组再按照名字排序
        for (NSMutableArray * mArr in [_peopleDic allValues]) {
            [mArr sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                return [[[obj1 name] uppercaseString] compare:[[obj2 name] uppercaseString]];
            }];
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [_tableView reloadData];
        });
    });
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [_peopleDic allKeys].count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //先获得排过序的key数组
    NSArray *sortKeyArray = [self sortArrayByString:[_peopleDic allKeys]];
    //根据区号取出这个区对应的key，然后根据key从字典中取出这个区对应的小数组。
    NSArray *sectionArray = [_peopleDic objectForKey:[sortKeyArray objectAtIndex:section]];
    
    return sectionArray.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"] autorelease];
    }
    NSArray *sortKeyArray = [self sortArrayByString:[_peopleDic allKeys]];
    NSArray *sectionArray = [_peopleDic objectForKey:[sortKeyArray objectAtIndex:indexPath.section]];
    
    People *p = [sectionArray objectAtIndex:indexPath.row];
    cell.textLabel.text = p.name;
    cell.detailTextLabel.text = p.phoneNumber;
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [[self sortArrayByString:[_peopleDic allKeys]] objectAtIndex:section];
}

- (nullable NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    
    return [self sortArrayByString:[_peopleDic allKeys]];
}

//按照字符串顺序排序
- (NSArray *)sortArrayByString:(NSArray *)array{
    return [array sortedArrayUsingSelector:@selector(compare:)];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
