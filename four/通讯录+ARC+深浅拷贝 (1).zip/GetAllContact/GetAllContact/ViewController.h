//
//  ViewController.h
//  GetAllContact
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray  *_peopleArray;
    
    IBOutlet UITableView *_tableView;
    
    NSMutableDictionary *_peopleDic;
    
}


@end








