//
//  People.h
//  GetAllContact
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface People : NSObject

@property (nonatomic,copy)NSString *name;

@property (nonatomic,copy)NSString *phoneNumber;

@end
