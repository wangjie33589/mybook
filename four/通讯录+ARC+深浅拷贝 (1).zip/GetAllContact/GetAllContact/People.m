//
//  People.m
//  GetAllContact
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People

- (void)dealloc{
    [_name release];
    [_phoneNumber release];
    [super dealloc];
}

- (NSString *)description{
    return [NSString stringWithFormat:@"姓名%@,电话%@",_name,_phoneNumber];
}


@end




