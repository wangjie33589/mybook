//
//  NSString+Pinyin.m
//  GetAllContact
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "NSString+Pinyin.h"

@implementation NSString (Pinyin)

- (NSString *)pinyin{
    NSMutableString *mStr = [NSMutableString stringWithString:self];
    
    //先转成带音调的拼音
    CFStringTransform((CFMutableStringRef)mStr, NULL, kCFStringTransformMandarinLatin, NO);
    
    //再把音调去掉
    CFStringTransform((CFMutableStringRef)mStr, NULL, kCFStringTransformStripDiacritics, NO);
    
    //去掉空格
    
    [mStr replaceOccurrencesOfString:@" " withString:@"" options:NSCaseInsensitiveSearch range:NSMakeRange(0, mStr.length)];
    
    return [NSString stringWithString:mStr];
    
}

@end









