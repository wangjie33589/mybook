//
//  People.m
//  CopyDemo
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People

//声明coping协议只是象征性的过程，主要是要实现协议方法。
- (id)copyWithZone:(nullable NSZone *)zone{
    //NSLog(@"%@",zone);
    
    //浅拷贝 return self;
    
    //深拷贝。
    
    People *p = [[[self class] alloc] init];
    //如果父类也遵守NSCoping协议，那么需要写
    //People *p = [[super class] copyWithZone:zone];
    p.name = self.name;
    p.age = self.age;
    
    return p;
}


@end





