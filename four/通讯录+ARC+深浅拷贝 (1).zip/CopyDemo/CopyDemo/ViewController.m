//
//  ViewController.m
//  CopyDemo
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "People.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *string1 = [NSString stringWithFormat:@"123"];
    
    NSString *string2 = [string1 copy];
//    NSLog(@"%p",string1);
//    NSLog(@"%p",string2);
    
    //浅拷贝：只拷贝指针，不拷贝对象，拷贝出来的指针指向拷贝的对象。(浅拷贝就相当于retain)
    
    //深拷贝：同时拷贝指针和对象，拷贝出来的指针指向拷贝出来的对象。(深拷贝才是真正的拷贝)
    
    NSString *str3 = [NSMutableString stringWithFormat:@"123"];
    NSString *str4 = [str3 copy];
    
//    NSLog(@"%p",str3);
//    NSLog(@"%p",str4);
    
    //copy和mutableCopy区别：copy得到的对象是不可变的，mutableCopy得到的对象是可变的。
    
    //NSString的copy是浅拷贝。
    //NSString的mutableCopy是深拷贝。
    //NSMutableString的copy是深拷贝。
    //NSMutableString的mutableCopy是深拷贝。
    
    NSArray *arr = [[NSArray alloc] initWithObjects:@"123", nil];
    
    NSArray *arr2 = [arr mutableCopy];
    
//    NSLog(@"%p",arr);
//    NSLog(@"%p",arr2);
    
    
    //对于容器类型(NSArray,NSDictionary,NSSet)的拷贝，至少拷贝一层对象就是深拷贝。
    
    //容器类型所有层的拷贝叫完全拷贝。
    
    //首先保证容器类中所有的对象都满足NSCoding协议。
    
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:arr];
    NSArray *arr3 = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    
    
    /*------自定义类的拷贝--------*/
    
    
    People *p1 = [[People alloc] init];
    p1.name = @"小明";
    p1.age = 13;
    
    //只有实现了NSCoping协议的对象才可以copy
    People *p2 = [p1 copy];
    
    NSLog(@"%p",p1);
    NSLog(@"%p",p2);
    
    NSLog(@"%@",p2.name);
    NSLog(@"%d",p2.age);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
