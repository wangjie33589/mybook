//
//  People.m
//  MemoryMRC
//
//  Created by sunhuayu on 15/10/20.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "People.h"

@implementation People



- (void)speak{
    NSLog(@"说话");
}


- (void)dealloc{
    NSLog(@"people释放了");
    [super dealloc];
}



@end





