//
//  SvGifAppDelegate.h
//  SvGifSample
//
//  Created by  maple on 3/28/13.
//  Copyright (c) 2013 smileEvday. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SvGifViewController;

@interface SvGifAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SvGifViewController *viewController;

@end
