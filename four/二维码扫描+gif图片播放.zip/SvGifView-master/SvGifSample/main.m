//
//  main.m
//  SvGifSample
//
//  Created by  maple on 3/28/13.
//  Copyright (c) 2013 smileEvday. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SvGifAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SvGifAppDelegate class]));
    }
}
