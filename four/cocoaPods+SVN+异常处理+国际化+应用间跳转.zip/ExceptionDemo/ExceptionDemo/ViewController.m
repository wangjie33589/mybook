//
//  ViewController.m
//  ExceptionDemo
//
//  Created by sunhuayu on 15/10/27.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSMutableArray *array = [[NSArray alloc] initWithObjects:@"123", nil];
    
    [array addObject:@"333"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
