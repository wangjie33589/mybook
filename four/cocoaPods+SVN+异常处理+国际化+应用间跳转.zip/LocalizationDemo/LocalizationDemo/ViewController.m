//
//  ViewController.m
//  LocalizationDemo
//
//  Created by sunhuayu on 15/10/27.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UILabel *label1 = [[UILabel alloc] initWithFrame:CGRectMake(20, 40, 100, 30)];
    
    //根据当前设备的语言环境，从语言对照表文件中取出这个字符串的值。
    label1.text = NSLocalizedString(@"today", nil);
    
    [self.view addSubview:label1];
    
    
    _imageView.image = [UIImage imageNamed:@"ali.png"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
