//
//  ViewController.m
//  BuyDemo
//
//  Created by sunhuayu on 15/10/27.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (IBAction)buttonClick:(UIButton *)sender {
    
    UIApplication *app = [UIApplication sharedApplication];
    
    NSURL *url = [NSURL URLWithString:@"Pay://?name=iphone&price=5288"];
    
    if ([app canOpenURL:url]) {
        [app openURL:url];
    }else{
        NSLog(@"您还没有安装支付软件");
        
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
