//
//  YellowController.h
//  StoryboardDemo
//
//  Created by sunhuayu on 15/10/21.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YellowController : UIViewController{
    
    __weak IBOutlet UITextField *_textField;
    
}


@end


