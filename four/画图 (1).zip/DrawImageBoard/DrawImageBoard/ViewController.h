//
//  ViewController.h
//  DrawImageBoard
//
//  Created by sunhuayu on 15/10/15.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIActionSheetDelegate>{
    
    __weak IBOutlet UIImageView *_imageView;
    
    UIColor     *_color;
    
    CGPoint     _lastPoint;
    
    float       _lineWidth;
    
    __weak IBOutlet UIView *_lineView;
    
}



@end







