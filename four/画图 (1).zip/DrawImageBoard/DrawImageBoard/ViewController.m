//
//  ViewController.m
//  DrawImageBoard
//
//  Created by sunhuayu on 15/10/15.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _color = [UIColor blackColor];
    
    _lineWidth = 5;
    
    self.view.backgroundColor = [UIColor lightGrayColor];
}


- (IBAction)colorButtonClick:(UIButton *)sender {
    switch (sender.tag) {
        case 1:
            _color = [UIColor blackColor];
            break;
        case 2:
            _color = [UIColor colorWithRed:1 green:1 blue:1 alpha:1];
            break;
        case 3:
            _color = [UIColor redColor];
            break;
        default:
            break;
    }
    
    _lineView.backgroundColor = _color;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    _lastPoint = [[touches anyObject] locationInView:_imageView];
    
    float scale = [UIScreen mainScreen].scale;
    
    //创建一个图形绘制上下文
    
    //在retina环境中，图形绘制最好绘制2倍的大小，否则画出的图会比较模糊。
    UIGraphicsBeginImageContext(CGSizeMake(_imageView.bounds.size.width*scale, _imageView.bounds.size.height*scale));
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextScaleCTM(context, scale, scale);
    
    //把imageView上原有的图片先画入上下文。
    [_imageView drawRect:_imageView.bounds];
    
    CGContextSetLineWidth(context, _lineWidth);
    CGContextSetStrokeColorWithColor(context, [_color CGColor]);
    CGContextSetLineCap(context, kCGLineCapRound);
    
    CGContextMoveToPoint(context, _lastPoint.x, _lastPoint.y);
    CGContextAddLineToPoint(context, _lastPoint.x, _lastPoint.y);
    
    CGContextDrawPath(context, kCGPathStroke);
    
    //把当前图形绘制上下文中的图片取出
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    _imageView.image = image;
    
    //结束图形绘制上下文
    UIGraphicsEndImageContext();
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    CGPoint thisPoint = [[touches anyObject] locationInView:_imageView];
    
    float scale = [UIScreen mainScreen].scale;
    
    //创建一个图形绘制上下文
    
    //在retina环境中，图形绘制最好绘制2倍的大小，否则画出的图会比较模糊。
    UIGraphicsBeginImageContext(CGSizeMake(_imageView.bounds.size.width*scale, _imageView.bounds.size.height*scale));
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextScaleCTM(context, scale, scale);
    
    //把imageView上原有的图片先画入上下文。
    [_imageView drawRect:_imageView.bounds];
    
    CGContextSetLineWidth(context, _lineWidth);
    CGContextSetStrokeColorWithColor(context, [_color CGColor]);
    CGContextSetLineCap(context, kCGLineCapRound);
    
    CGContextMoveToPoint(context, _lastPoint.x, _lastPoint.y);
    CGContextAddLineToPoint(context, thisPoint.x, thisPoint.y);
    
    CGContextDrawPath(context, kCGPathStroke);
    
    //把当前图形绘制上下文中的图片取出
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    _imageView.image = image;
    
    //结束图形绘制上下文
    UIGraphicsEndImageContext();
    
    _lastPoint = thisPoint;
}


- (IBAction)sliderValueChange:(UISlider *)sender {
    _lineWidth  = sender.value*9+1;
    
    _lineView.bounds = CGRectMake(0, 0, _lineView.bounds.size.width, _lineWidth);
}


- (IBAction)saveButtonClick:(UIButton *)sender {
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"保存" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"保存绘制图片",@"保存屏幕截图", nil];
    
    [sheet showInView:self.view];
    
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        //保存绘制图片
        UIImageWriteToSavedPhotosAlbum(_imageView.image, nil, nil, nil);
    }else if (buttonIndex == 1){
        //保存屏幕截图
        
        UIGraphicsBeginImageContext(CGSizeMake(self.view.bounds.size.width*2, self.view.bounds.size.height*2));
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextScaleCTM(context, 2, 2);
        
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        
        //renderInContext把layer上的内容渲染到一个图形绘制上下文中。
        [window.layer renderInContext:context];
        
        UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
        
        UIGraphicsEndImageContext();
        
    }else{
        
    }
}


@end







