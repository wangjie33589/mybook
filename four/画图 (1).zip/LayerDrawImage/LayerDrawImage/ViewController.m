//
//  ViewController.m
//  LayerDrawImage
//
//  Created by sunhuayu on 15/10/15.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CALayer *layer = [CALayer layer];
    
    layer.bounds = self.view.bounds;
    layer.position = self.view.center;
    [self.view.layer addSublayer:layer];
    
    //要在layer上直接画图，需要设置代理
    layer.delegate = self;
    
    //解决图片模糊问题
    layer.contentsScale = [[UIScreen mainScreen] scale];
    
    //必须调用setNeedsDisplay方法，layer才能使用drawLayer方法绘图。
    [layer setNeedsDisplay];
}

//layer的代理方法，方法中写对这个layer进行绘制的代码。
- (void)drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx{
    
    CGContextSetLineWidth(ctx, 5);
    
    CGContextSetStrokeColorWithColor(ctx, [[UIColor blackColor] CGColor]);
    
    CGContextMoveToPoint(ctx, 30, 30);
    
    CGContextAddLineToPoint(ctx, 300, 30);
    
    CGContextDrawPath(ctx, kCGPathStroke);
    
    UIImage *image = [UIImage imageNamed:@"ali.png"];
    
    //解决图片倒立问题
//    CGContextScaleCTM(ctx, 1, -1);
//    CGContextTranslateCTM(ctx, 0, -layer.bounds.size.height);
    
//    CGContextDrawImage(ctx, CGRectMake(30, 50, 200, 200), [image CGImage]);
    
    UIGraphicsPushContext(ctx);
    
    [image drawInRect:CGRectMake(30, 50, 200, 200)];
    
    UIGraphicsPopContext();
    
    //获得当前编辑点的位置
    //CGContextGetPathCurrentPoint(ctx);
}



@end





