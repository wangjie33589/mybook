//
//  MyView.m
//  DrawImage1
//
//  Created by sunhuayu on 15/10/15.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "MyView.h"

@implementation MyView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.


//要在UIView中绘图，必须重写drawRect，在drawRect中进行绘制。绘制的内容实质上是在view.layer上进行绘制。
- (void)drawRect:(CGRect)rect {
    
    //CGContextRef图形绘制上下文，图形绘制必须在上下文中进行。
    
    //UIGraphicsGetCurrentContext获得当前的图形绘制上下文。
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //设置绘制线条宽度
    CGContextSetLineWidth(context, 5);
    
    //设置绘制线条的颜色。
    CGContextSetStrokeColorWithColor(context, [[UIColor blackColor] CGColor]);
    
    //使用RGB值设置线条颜色。
    //CGContextSetRGBStrokeColor(context, 0.5, 0.5, 0.5, 1);
    
    //设置线条两端的样式
    CGContextSetLineCap(context, kCGLineCapRound);
    
    //设置线条拐角的样式
    CGContextSetLineJoin(context, kCGLineJoinRound);
    
    //把画笔移动到某个坐标位置
    CGContextMoveToPoint(context, 30, 30);
    
    //画一条直线到某个坐标点。
    CGContextAddLineToPoint(context, 200, 30);
    
    CGContextAddLineToPoint(context, 200, 100);
    
    //执行绘制，把context中的图形绘制到layer上。
    CGContextDrawPath(context, kCGPathStroke);
    
    /*---------画矩形------*/
    //绘制矩形
    CGContextAddRect(context, CGRectMake(30, 150, 100, 50));
    
    //设置填充颜色
    CGContextSetFillColorWithColor(context, [[UIColor redColor] CGColor]);
    
    CGContextDrawPath(context, kCGPathFillStroke);
    
    /*-------弧线--------*/
    
    CGContextAddArc(context, 200, 300, 100, -70*M_PI/180, -110*M_PI/180, YES);
    
    CGContextDrawPath(context, kCGPathStroke);
    
    //画扇形
    CGContextMoveToPoint(context, 30, 230);
    CGContextAddLineToPoint(context, 60, 290);
    CGContextAddLineToPoint(context, 90, 230);
    
    float radius = sqrt(pow(30, 2)+pow(60, 2));
    
    CGContextMoveToPoint(context, 30, 230);
    
    CGContextAddArc(context, 60, 290, radius, 270*M_PI/180-atan(0.5), 270*M_PI/180+atan(0.5), NO);
    
    CGContextDrawPath(context, kCGPathFillStroke);
    
    //绘制椭圆
    CGContextAddEllipseInRect(context, CGRectMake(150, 230, 60, 30));
    CGContextDrawPath(context, kCGPathFillStroke);
    
    //文本绘制
    NSString *text = @"今天星期四";
    
    [text drawInRect:CGRectMake(30, 300, 200, 30) withAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12],NSForegroundColorAttributeName:[UIColor blueColor]}];
    
    //图片绘制
    UIImage *image = [UIImage imageNamed:@"ali.png"];
    
    [image drawInRect:CGRectMake(30, 330, 100, 100)];
    
    
}


@end








