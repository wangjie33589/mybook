//
//  MyView.h
//  DrawImage1
//
//  Created by sunhuayu on 15/10/15.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView

@end
