//
//  ViewController.m
//  CALayer
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
//#import <QuartzCore/QuartzCore.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //CALayer层，每一个UIView都有一个根layer。layer是UIView的图形绘制部分。
    
    //CALayer直接继承于NSObject,所以不能相应touch事件。
    
    _layer = [CALayer layer];
    
    //背景颜色
    _layer.backgroundColor = [[UIColor greenColor] CGColor];
    
    //添加子层
    [self.view.layer addSublayer:_layer];
    
    //layer一般情况下不用frame，而是使用bounds+position
    //_layer.frame = CGRectMake(30, 30, 40, 40);
    
    //layer的尺寸
    _layer.bounds = CGRectMake(0, 0, 100, 100);
    
    //layer的位置，指的是锚点位置。
    _layer.position = self.view.center;
    
    //锚点，默认值(0.5,0.5)。
    _layer.anchorPoint = CGPointMake(0.5, 0.5);
    
    //设置圆角半径
    _layer.cornerRadius = 20;
    
    
    CALayer *layer = [CALayer layer];
    //设置layer的内容，仅能够设置图片。
    layer.contents = (id)[[UIImage imageNamed:@"ali.png"] CGImage];
    layer.cornerRadius = 20;
    //边界裁剪，不显示自身frame之外的子层部分。
    layer.masksToBounds = YES;
    layer.bounds = CGRectMake(0, 0, 100, 100);
    layer.position = CGPointMake(50, 50);
    [_layer addSublayer:layer];
    
    
    //边框宽度
    _layer.borderWidth = 5;
    
    //边框颜色
    _layer.borderColor = [[UIColor blueColor] CGColor];
    
    //透明度
    _layer.opacity = 1;
    
    //maskToBounds为YES时，阴影不会显示。
    //设置阴影的位置
    _layer.shadowOffset = CGSizeMake(10, 10);
    //设置阴影的颜色
    _layer.shadowColor = [[UIColor blackColor] CGColor];
    //阴影透明度
    _layer.shadowOpacity = 0.7;
    //阴影圆角(模糊程度)
    _layer.shadowRadius = 7;
    
    //layer的变形效果
    CATransform3D transform = CATransform3DRotate (_layer.transform, 30*M_PI/180,               1, 0, 0);
    
    _layer.transform = transform;
    
    
    //梯度层，可以显示一个渐变的颜色
    CAGradientLayer *layer2 = [CAGradientLayer layer];
    
    layer2.bounds = CGRectMake(0, 0, 100, 100);
    layer2.position = CGPointMake(50, 50);
    [self.view.layer addSublayer:layer2];
    
    CGColorRef red = [[UIColor redColor] CGColor];
    CGColorRef blue = [[UIColor blueColor] CGColor];
    CGColorRef green = [[UIColor greenColor] CGColor];
    
    layer2.colors = @[(__bridge UIColor*)red,(__bridge UIColor*)blue,(__bridge UIColor*)green];
    
    layer2.startPoint = CGPointMake(0, 0);
    layer2.endPoint = CGPointMake(1, 0);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
