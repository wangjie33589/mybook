//
//  ViewController.m
//  CoreAnimation2
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _layer = [CALayer layer];
    _layer.bounds = CGRectMake(0, 0, 50, 50);
    _layer.position = CGPointMake(25, 25);
    _layer.backgroundColor = [[UIColor redColor] CGColor];
    _layer.cornerRadius = 25;
    _layer.borderWidth = 3;
    [self.view.layer addSublayer:_layer];
}

- (IBAction)jumpAnimationClick:(UIButton *)sender {
    
    //CAKeyframeAnimation关键帧动画。
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position.y"];
    
    animation.duration = 1.5;
    
    //每一个关键帧的值。
    animation.values = @[@25,@543,@175,@543,@325,@543,@440,@543];
    
    //每两个关键帧之间动画的动画速率
    NSMutableArray *arr = [NSMutableArray arrayWithCapacity:7];
    for (int i = 0; i<7; i++) {
        CAMediaTimingFunction *function = [CAMediaTimingFunction functionWithName:i%2 == 1?kCAMediaTimingFunctionEaseOut:kCAMediaTimingFunctionEaseIn];
        [arr addObject:function];
    }
    
    animation.timingFunctions = arr;
    
    //设置每个动画的时间分配；默认为平均分配。
    //设置每一帧所在的时间比。范围0-1，必须是一个递增序列。
    animation.keyTimes = @[@0,@(1.0/7),@(2.0/7),@(3.0/7),@(4.0/7),@(5.0/7),@(6.0/7),@(7.0/7)];
    
    [_layer addAnimation:animation forKey:@"jump"];
}

- (IBAction)rectAnimationClick:(UIButton *)sender {
    //路径动画，按照设置的路径运动。
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    
    //UIBezierPath贝塞尔曲线路径，
    UIBezierPath *path = [UIBezierPath bezierPath];
    //开始画线，把编辑坐标点移动到初始位置。
    [path moveToPoint:CGPointMake(25, 25)];
    
    //画一条线到目标位置。
    [path addLineToPoint:CGPointMake(295, 25)];
    
    [path addLineToPoint:CGPointMake(295, 543)];
    [path addLineToPoint:CGPointMake(25, 543)];
    //闭合路径，相当于画一条直线连接到路径开始点
    [path closePath];
    
    animation.duration = 1.5;
    
    //设置动画路径
    animation.path = [path CGPath];
    
    [_layer addAnimation:animation forKey:@"rect"];
}

- (IBAction)roundAnimationClick:(UIButton *)sender {
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    
    //画一个弧线。
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:self.view.center radius:130 startAngle:0 endAngle:M_PI*2 clockwise:YES];
    //animation.repeatCount = HUGE_VAL;
    
    animation.duration = 1.5;
    animation.path = [path CGPath];
    [_layer addAnimation:animation forKey:@"round"];
}

- (IBAction)curveAnimationClick:(UIButton *)sender {
    UIBezierPath *path = [UIBezierPath bezierPath];
    
    [path moveToPoint:CGPointMake(25, 25)];
    
    [path addQuadCurveToPoint:CGPointMake(295, 543) controlPoint:CGPointMake(250, 50)];
    
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    animation.duration = 1.5;
    animation.path = [path CGPath];
    [_layer addAnimation:animation forKey:@"curve"];
}


- (IBAction)animationGroupClick:(UIButton *)sender {
    CAAnimationGroup *group = [CAAnimationGroup animation];
    
    CABasicAnimation *moveAnimation = [CABasicAnimation animationWithKeyPath:@"position.y"];
    moveAnimation.toValue = @300;
    //moveAnimation.duration = 1.5;
    
    CABasicAnimation *colorAnimation = [CABasicAnimation animationWithKeyPath:@"backgroundColor"];
    colorAnimation.toValue = (__bridge id)([[UIColor greenColor] CGColor]);
    
    group.animations = @[moveAnimation,colorAnimation];
    group.duration = 1.5;
    
    [_layer addAnimation:group forKey:@"group"];
    
}


@end








