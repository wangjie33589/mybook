//
//  ViewController.m
//  LayerAnimation
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _layer = [CALayer layer];
    _layer.bounds = CGRectMake(0, 0, 100, 100);
    _layer.position = self.view.center;
    [self.view.layer addSublayer:_layer];
    _layer.backgroundColor = [[UIColor redColor] CGColor];
    _layer.contents = (id)[[UIImage imageNamed:@"ali.png"] CGImage];
    
    CATransform3D transform = _layer.transform;
    
    transform.m34 = 0.01;
    
    _layer.transform = transform;
    
    _layer.anchorPoint = CGPointMake(0.5, 0.5);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    
    CGPoint point = [touch locationInView:self.view];
    
    //事物类，控制layer动画。
    
    //设置隐式动画的动画时间
    [CATransaction setAnimationDuration:0.5];
    
    
    //设置隐式动画的动画速率
    [CATransaction setAnimationTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
    
    //关闭隐式动画。YES为关闭，NO为开启
    [CATransaction setDisableActions:NO];
    
    //layer大部分属性的修改都是自带动画的，这个动画叫做隐式动画。
    _layer.position = point;
//    CGFloat width = _layer.bounds.size.width;
//    _layer.bounds = CGRectMake(0, 0, width == 50?100:50,  width == 50?100:50);
    
    //动画总是以锚点为参照点。
    CATransform3D transform = CATransform3DRotate(_layer.transform, 30*M_PI/180, 0, 1, 0);
    _layer.transform = transform;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
