//
//  ViewController.m
//  CoreAnimation1
//
//  Created by sunhuayu on 15/10/13.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _layer = [CALayer layer];
    _layer.bounds = CGRectMake(0, 0, 50, 50);
    _layer.position = CGPointMake(50, 300);
    _layer.backgroundColor = [[UIColor redColor] CGColor];
    _layer.borderWidth = 3;
    [self.view.layer addSublayer:_layer];
}

- (IBAction)moveAnimationClick:(UIButton *)sender {
    
    //核心动画类，不能直接使用，一般都是使用它的子类。
    //CAAnimation
    
    
    //CABasicAnimation基础动画，常用于简单的位移和变形动画。
    //animationWithKeyPath指定动画改编的属性。
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"position.x"];
    
    //设置动画的初始值，可以不设置，不设置的话按照layer的位置当做初始值。
    //animation.fromValue = [NSValue valueWithCGPoint:CGPointMake(50, 300)];
    
//    //toValue设置动画的结束值。
//    animation.toValue = [NSValue valueWithCGPoint:CGPointMake(200, 300)];
    
    //byValue设置动画的改变量
    animation.byValue = @150;
    
    //设置动画每次执行的时间
    animation.duration = 2;
    
    //动画结束之后再以动画返回初始位置
    animation.autoreverses = YES;
    
//    //动画重复的次数
    animation.repeatCount = 1;
    
    //动画执行的总时间，如果总时间大于每次时间，动画就会多次执行。不能和animation.repeatCount一起使用。
//    animation.repeatDuration = HUGE_VAL;
    
    //动画结束后，是否自动从layer上移除，默认为YES.
    animation.removedOnCompletion = NO;
    
    //动画开始和结束时，layer是否停留在动画位置。这个属性仅当removedOnCompletion为NO时生效。
    animation.fillMode = kCAFillModeBoth;
    
    //设置动画的代理，当动画开始或结束时，就会调用代理对象的方法。
    animation.delegate = self;
    
    //CAAnimation必须添加到layer上才会被执行。
    [_layer addAnimation:animation forKey:@"moveAnimation"];
}

- (IBAction)rorateClick:(UIButton *)sender {
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    
    animation.byValue = [NSNumber numberWithFloat:90*M_PI/180];
    
    animation.repeatCount = HUGE_VAL;
    
    [_layer addAnimation:animation forKey:@"rotate"];
}

- (IBAction)stopAnimation:(UIButton *)sender {
    //移除layer上的所有动画
    [_layer removeAllAnimations];
}


//当CAAnimation动画结束时调用。
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    NSLog(@"%d",flag);
    CABasicAnimation *animation = (CABasicAnimation *)anim;
    if (anim == [_layer animationForKey:@"moveAnimation"]) {
//        [CATransaction setDisableActions:YES];
//        _layer.position = CGPointMake(_layer.position.x+[animation.byValue floatValue], 300);
    }
    
    [_layer removeAnimationForKey:@"moveAnimation"];
}


@end











