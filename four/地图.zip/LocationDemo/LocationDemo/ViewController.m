//
//  ViewController.m
//  LocationDemo
//
//  Created by sunhuayu on 15/10/16.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    //定位管理器，可以获得用户所在的位置坐标（经纬度），还可以获得设备的面朝方向。
    _manager = [[CLLocationManager alloc] init];
    
    //从IOS8开始，定位权限需要主动申请。
    
    //程序在后台也可以定位
    [_manager requestAlwaysAuthorization];
    
//    //程序只有在运行时可以使用定位
//    [_manager requestWhenInUseAuthorization];
    
    //设置代理，manager会通过调用代理方法把方向和位置传给代理对象。
    _manager.delegate = self;
    
    //先判断方向功能是否可用
    if ([CLLocationManager headingAvailable]) {
        
        //设置方向判断的精确度。
        _manager.headingFilter = 5;
        
        //开始判断方向
        [_manager startUpdatingHeading];
    }
    
    //判断定位功能是否可用
    if ([CLLocationManager locationServicesEnabled]) {
        
        //更新位置坐标的最小移动距离。
        _manager.distanceFilter = 1;
        
        //设置获取位置的精确度。
        _manager.desiredAccuracy = kCLLocationAccuracyBest;
        
        //开始定位
        [_manager startUpdatingLocation];
    }
    
}

//设备方向改变时的回调方法。
- (void)locationManager:(CLLocationManager *)manager
       didUpdateHeading:(CLHeading *)newHeading{
    
//    //磁力计方向。
//    NSLog(@"磁力方向%f",newHeading.magneticHeading);
//    
//    //地理方向。0表示正北方。
//    NSLog(@"地理方向%f",newHeading.trueHeading);
}


//当位置发生改变时的调用方法。
- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray<CLLocation *> *)locations{
    
    //获得最后一个定位的坐标
    CLLocation *loca = [locations lastObject];
    
    //获取这个位置的定位时间
    NSDate *date = loca.timestamp;
    
    float time = [date timeIntervalSinceNow];
    
    //判断定位时间是否距离现在过长，导致位置上的偏差。
    if (ABS(time)<15) {
        //纬度
        NSLog(@"纬度%f",loca.coordinate.latitude);
        
        //经度
        NSLog(@"经度%f",loca.coordinate.longitude);
    }
    
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"定位功能打开失败,%@",error);
    
    //停止定位的更新。
    [_manager stopUpdatingHeading];
    [_manager stopUpdatingLocation];
}


@end






