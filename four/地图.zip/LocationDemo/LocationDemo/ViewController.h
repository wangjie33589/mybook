//
//  ViewController.h
//  LocationDemo
//
//  Created by sunhuayu on 15/10/16.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@interface ViewController : UIViewController<CLLocationManagerDelegate>{
    
    //定位管理器
    CLLocationManager   *_manager;
}


@end







