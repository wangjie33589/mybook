//
//  ViewController.m
//  MapViewDemo
//
//  Created by sunhuayu on 15/10/16.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "ViewController.h"
#import "MyAnnotation.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _manager = [[CLLocationManager alloc] init];
    
    [_manager requestWhenInUseAuthorization];
    
    _map = [[MKMapView alloc] initWithFrame:self.view.bounds];
    
    _map.delegate = self;
    
    //是否显示用户所在位置
    _map.showsUserLocation = YES;
    
    _map.userLocation.title = @"我的位置";
    _map.userLocation.subtitle = @"智游";
    
    //设置地图样式，普通地图，卫星地图。
    _map.mapType = MKMapTypeStandard;
    
    [self.view addSubview:_map];
    
    [self.view sendSubviewToBack:_map];
    
    MyAnnotation *home = [[MyAnnotation alloc] init];
    
    home.coordinate = CLLocationCoordinate2DMake(34.729420, 113.746140);
    
    
    [_map addAnnotation:home];
    
}

- (IBAction)showUserPosition:(UIButton *)sender {
    
    //获得用户所在的坐标
    CLLocationCoordinate2D coordinate = _map.userLocation.location.coordinate;
    
    //根据坐标点，生成一个区域。
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordinate, 1000, 1000);
    
    //让地图显示某个区域。
    [_map setRegion:region animated:YES];
    
}

- (IBAction)showPointClick:(UIButton *)sender {
    
    //大头针
    MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
    
    point.title = @"大头针";
    point.subtitle = @"黄焖鸡米饭";
    
    //设置大头针显示的位置
    point.coordinate = _map.userLocation.location.coordinate;
    
    //在地图上添加大头针
    [_map addAnnotation:point];
    
    
    //移除大头针
    //[_map removeAnnotation:point];
    
    
}

- (nullable MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation{
    
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    
    if ([annotation isKindOfClass:[MyAnnotation class]]) {
        MKAnnotationView *view = [[MKAnnotationView alloc] init];
        view.image = [UIImage imageNamed:@"ali.png"];
        
        return view;
    }
    
    MKPinAnnotationView *view = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:@"view"];
    if (!view) {
        view = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"view"];
        
    }
    
    view.pinTintColor = [UIColor greenColor];
    
    //出现时是否带动画
    view.animatesDrop = YES;
    
    //是否能够显示title
    view.canShowCallout = YES;
    
    return view;
}


@end










