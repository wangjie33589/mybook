//
//  MyAnnotation.m
//  MapViewDemo
//
//  Created by sunhuayu on 15/10/16.
//  Copyright © 2015年 sunhuayu. All rights reserved.
//

#import "MyAnnotation.h"

@implementation MyAnnotation

@end
